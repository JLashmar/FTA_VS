from django.apps import AppConfig


class teamsConfig(AppConfig):
    name = 'teams'
