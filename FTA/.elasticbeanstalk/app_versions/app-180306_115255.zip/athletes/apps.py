from django.apps import AppConfig


class athletesConfig(AppConfig):
    name = 'athletes'
