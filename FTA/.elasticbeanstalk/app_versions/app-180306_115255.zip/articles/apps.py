from django.apps import AppConfig


class articlesConfig(AppConfig):
    name = 'articles'
