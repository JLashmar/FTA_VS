"""
Package for FTA.
"""
