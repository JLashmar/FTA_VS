from django.apps import AppConfig


class NationsConfig(AppConfig):
    name = 'nations'
