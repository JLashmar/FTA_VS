from django.apps import AppConfig


class sportsConfig(AppConfig):
    name = 'sports'
